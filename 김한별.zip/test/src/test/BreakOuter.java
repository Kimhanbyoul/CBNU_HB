package test;

public class BreakOuter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		outLoop:
			
			for(int i=0; i<3; i++){
				for(int j=0; j<3; j++){
					System.out.println("i:" + i + "-j:" + j);
					if(i==1 && j==2)
						break outLoop;
				}
			}
	}

}
//2016039048 ���Ѻ�