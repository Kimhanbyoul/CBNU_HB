package test;

public class ForTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int a=1;a<6;a++)
		{
			System.out.println("a="+a);
		}
	}

}

//2016039048 ���Ѻ�