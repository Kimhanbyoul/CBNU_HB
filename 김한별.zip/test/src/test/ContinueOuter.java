package test;

public class ContinueOuter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		outLoop: for (int i = 0; i < 3; i++) {
			
			for (int j=0; j<5; j++) {
				System.out.println("i:" + i + "-j:" + j);
				if (j == 2)
					continue outLoop;
			}
		}
	}

}
//2016039048 ���Ѻ�