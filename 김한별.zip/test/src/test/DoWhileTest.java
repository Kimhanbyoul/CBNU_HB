package test;

public class DoWhileTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=0;
		do
		{
			a++;
			System.out.println("a="+a);
		}
		while(a<5);
	}

}
//2016039048 ���Ѻ�